-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 13, 2023 at 05:44 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webphone`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
CREATE TABLE IF NOT EXISTS `account` (
  `Username` varchar(64) NOT NULL,
  `FirstName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Email` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SDT` int DEFAULT NULL,
  `PassWord` int DEFAULT NULL,
  PRIMARY KEY (`Username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Username`, `FirstName`, `Email`, `SDT`, `PassWord`) VALUES
('dc01', 'dc', 'dangcuong@gmail.com', 123456789, NULL),
('dc02', 'dc', 'dangcuong1@gmail.com', 123456788, NULL),
('Hung ', 'Cuong ', 'dangcuong9999@gmail.com ', 123456781, NULL),
('HungCuong1', 'Hung', 'dangcuong9999@gmail.com', 123456989, 12345678),
('abc123', 'TEST', 'test@fake.com', 123434589, 123456789);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `MaSP` int NOT NULL,
  `TenSP` varchar(64) DEFAULT NULL,
  `MoTaSP` text,
  `DonViTinh` varchar(64) DEFAULT NULL,
  `DonGia` int DEFAULT NULL,
  `ThoiDiemCapNhat` timestamp NULL DEFAULT NULL,
  `link hinh anh` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`MaSP`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`MaSP`, `TenSP`, `MoTaSP`, `DonViTinh`, `DonGia`, `ThoiDiemCapNhat`, `link hinh anh`) VALUES
(1, 'Ốp điện thoại gỗ chất lượng cao', 'Được làm bằng gỗ chất lượng cao', 'Số lượng', 100000, '2023-04-26 01:35:21', 'opgoxiem.jpg'),
(2, 'Ốp gỗ quý nghìn năm', 'Ốp gỗ quý nghìn năm tuổi từ cây cổ thụ', 'Số Lượng', 200000, '2023-04-26 04:13:45', 'opgocothu.jpg'),
(3, 'Ốp lưng gỗ VERTU', 'Ốp điện thoại dành riêng cho dòng VERTU', NULL, 400000, '2023-05-06 07:02:13', 'opgo5.jpg'),
(4, 'Ốp lưng gỗ trắc', 'Ốp lưng gỗ truyền thống', 'Số Lượng', 80000, '2023-04-29 14:58:32', 'opgo4.jpg'),
(5, 'Ốp lưng gỗ xà nu', 'Ốp lưng gỗ xà nu chất lương cao không tì vết', 'Số lượng', 300000, '2023-04-26 02:52:56', 'oplunghavard.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
